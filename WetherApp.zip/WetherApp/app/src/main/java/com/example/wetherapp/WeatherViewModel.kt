package com.example.wetherapp


import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class WeatherViewModel : ViewModel() {


    private val _weatherData = MutableLiveData<WeatherResponse>()
    val weatherData: LiveData<WeatherResponse> = _weatherData

    private val _error = MutableLiveData<String>()
    val error: LiveData<String> = _error

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    // API ключ
    private val apiKey = "3510da38014ee11aca2467a230749c88"
    fun fetchWeather(city: String) {
        if (apiKey == "ВАШ_API_КЛЮЧ") {
            _error.value = "Добавьте API ключ в WeatherViewModel.kt"
            return
        }

        _isLoading.value = true
        _error.value = null

        viewModelScope.launch {
            val call = WeatherApi.retrofitService.getCurrentWeather(city, apiKey)

            call.enqueue(object : Callback<WeatherResponse> {
                override fun onResponse(
                    call: Call<WeatherResponse>,
                    response: Response<WeatherResponse>
                ) {
                    _isLoading.value = false

                    if (response.isSuccessful) {
                        _weatherData.value = response.body()
                    } else {
                        _error.value = when (response.code()) {
                            404 -> "Город не найден"
                            401 -> "Неверный API ключ"
                            else -> "Ошибка: ${response.code()}"
                        }
                    }
                }

                override fun onFailure(call: Call<WeatherResponse>, t: Throwable) {
                    _isLoading.value = false
                    _error.value = "Ошибка сети: ${t.message}"
                }
            })
        }
    }

    fun formatTemperature(temp: Double): String {
        return "${temp.toInt()}°C"
    }


    fun getWeatherIconUrl(iconCode: String): String {
        return "https://openweathermap.org/img/wn/${iconCode}@2x.png"
    }
}