package com.example.wetherapp

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.lifecycle.ViewModelProvider
import com.squareup.picasso.Picasso

class MainActivity : AppCompatActivity() {

    // View
    private lateinit var cityEditText: EditText
    private lateinit var searchButton: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var errorTextView: TextView
    private lateinit var weatherCard: CardView
    private lateinit var cityTextView: TextView
    private lateinit var tempTextView: TextView
    private lateinit var descriptionTextView: TextView
    private lateinit var weatherIcon: ImageView
    private lateinit var humidityTextView: TextView
    private lateinit var pressureTextView: TextView
    private lateinit var windTextView: TextView
    private lateinit var tempMaxTextView: TextView
    private lateinit var tempMinTextView: TextView

    private lateinit var viewModel: WeatherViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        initViews()


        viewModel = ViewModelProvider(this)[WeatherViewModel::class.java]


        setupObservers()


        setupListeners()


        viewModel.fetchWeather("Москва")
    }

    private fun initViews() {
        cityEditText = findViewById(R.id.cityEditText)
        searchButton = findViewById(R.id.searchButton)
        progressBar = findViewById(R.id.progressBar)
        errorTextView = findViewById(R.id.errorTextView)
        weatherCard = findViewById(R.id.weatherCard)
        cityTextView = findViewById(R.id.cityTextView)
        tempTextView = findViewById(R.id.tempTextView)
        descriptionTextView = findViewById(R.id.descriptionTextView)
        weatherIcon = findViewById(R.id.weatherIcon)
        humidityTextView = findViewById(R.id.humidityTextView)
        pressureTextView = findViewById(R.id.pressureTextView)
        windTextView = findViewById(R.id.windTextView)
        tempMaxTextView = findViewById(R.id.tempMaxTextView)
        tempMinTextView = findViewById(R.id.tempMinTextView)
    }

    private fun setupObservers() {

        viewModel.weatherData.observe(this) { weather ->
            weather?.let {
                weatherCard.visibility = View.VISIBLE
                updateWeatherUI(it)
            }
        }


        viewModel.error.observe(this) { error ->
            error?.let {
                errorTextView.text = it
                errorTextView.visibility = View.VISIBLE
                Toast.makeText(this, it, Toast.LENGTH_LONG).show()
            }
        }


        viewModel.isLoading.observe(this) { isLoading ->
            if (isLoading == true) {
                progressBar.visibility = View.VISIBLE
                weatherCard.visibility = View.GONE
                errorTextView.visibility = View.GONE
            } else {
                progressBar.visibility = View.GONE
            }
        }
    }

    private fun setupListeners() {
        searchButton.setOnClickListener {
            val city = cityEditText.text.toString().trim()
            if (city.isNotEmpty()) {
                hideKeyboard()
                viewModel.fetchWeather(city)
            } else {
                Toast.makeText(this, "Введите название города", Toast.LENGTH_SHORT).show()
            }
        }

        cityEditText.setOnEditorActionListener { _, _, _ ->
            searchButton.performClick()
            true
        }
    }

    private fun updateWeatherUI(weather: WeatherResponse) {

        cityTextView.text = "${weather.cityName}, ${weather.sys.country}"


        tempTextView.text = viewModel.formatTemperature(weather.main.temperature)


        val weatherDescription = weather.weather.firstOrNull()
        if (weatherDescription != null) {
            descriptionTextView.text = weatherDescription.description.capitalize()


            val iconUrl = viewModel.getWeatherIconUrl(weatherDescription.icon)
            Picasso.get()
                .load(iconUrl)
                .into(weatherIcon)
        }


        humidityTextView.text = "${weather.main.humidity}%"


        pressureTextView.text = "${weather.main.pressure} hPa"


        windTextView.text = "${weather.wind.speed} м/с"


        tempMaxTextView.text = viewModel.formatTemperature(weather.main.tempMax)
        tempMinTextView.text = viewModel.formatTemperature(weather.main.tempMin)


        val feelsLike = viewModel.formatTemperature(weather.main.feelsLike)
        Toast.makeText(this, "Ощущается как $feelsLike", Toast.LENGTH_SHORT).show()
    }

    private fun hideKeyboard() {
        val view = this.currentFocus
        view?.let {
            val imm = getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
            imm.hideSoftInputFromWindow(it.windowToken, 0)
        }
    }
}